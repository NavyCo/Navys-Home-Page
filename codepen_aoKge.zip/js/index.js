$("[fancybox]").fancybox({
  openEffect: 'elastic',
  closeEffect: 'fade',
});